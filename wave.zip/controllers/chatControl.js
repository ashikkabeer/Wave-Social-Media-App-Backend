

class chatControls {
    constructor() {
        this.sendMessage.bind(this);
    }
    async sendMessage(req,res) {

    }

    async getChatHistory(req,res) {
        
    }
}